import os
import pyogrio
import rasterio
from rasterio.warp import transform_bounds
from shapely.geometry import box

def process_arctic_files():
    try:
        # Load Arctic shapefile
        arctic_shp = pyogrio.read_dataframe('/workspace/data/AllMapsInOneFolder/Arctic/NMD2023_RT90_Arctic.shp')
        print("Loaded Arctic shapefile successfully")
        
        # Create Arctic output directory
        arctic_dir = '/workspace/data/AllMapsInOneFolder/PredictionsArable/Arctic'
        os.makedirs(arctic_dir, exist_ok=True)
        print(f"Created output directory: {arctic_dir}")
        
        # Source directory with predictions
        pred_dir = '/workspace/data/AllMapsInOneFolder/PredictionsArable/'
        
        if not os.path.exists(pred_dir):
            raise FileNotFoundError(f"Predictions directory not found: {pred_dir}")
            
        # Process each TIF
        moved_count = 0
        for tif_name in os.listdir(pred_dir):
            if not tif_name.endswith('.tif'):
                continue
                
            tif_path = os.path.join(pred_dir, tif_name)
            print(f"Processing: {tif_name}")
            
            # Read TIF bounds and check intersection
            with rasterio.open(tif_path) as src:
                bounds = src.bounds
                if src.crs != arctic_shp.crs:
                    bounds = transform_bounds(src.crs, arctic_shp.crs, *bounds)
                tif_geom = box(*bounds)
                
                if any(arctic_shp.geometry.intersects(tif_geom)):
                    dest_path = os.path.join(arctic_dir, tif_name)
                    os.rename(tif_path, dest_path)
                    moved_count += 1
                    print(f"Moved {tif_name} to Arctic folder")

        print(f"\nCompleted: Moved {moved_count} files to Arctic folder")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        raise

if __name__ == "__main__":
    process_arctic_files()